# coding:utf-8

#__all__针对的是import *

__all__ = ['淘宝APPapi','淘宝H5API','淘宝开放平台API','淘宝通用API']
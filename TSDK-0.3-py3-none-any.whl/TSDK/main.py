from api.taobao.h5 import TaobaoH5



if __name__ == '__main__':
    h5 = TaobaoH5()
    # h5.loadCookieStr('cna=a8zpHfOqU3MCAXWYXEdnMpvF; _m_h5_tk=10556b1751f9571eab54ac23aab278e3_1700994933988; _m_h5_tk_enc=f0739dc3daf7fb94cd31c5fbbd067ac9; cookie2=19b1458e82cac746a0c328059e3bbb4b; t=bcc413442c8fbf9d2eab1b7d756a0ba0; _tb_token_=e1603f9b7e9f6; _samesite_flag_=true; sgcookie=E100vIHqs%2Bjcl%2BNJvD4s%2F2CU53lrV%2FgKJK6DgchdHhrrTpFLHrZozXfKKdRM1RWF%2Fz6BYBh4dSXMlzPF48fYWwUH2QmRMhrupMxL4il781Y734%2FQk3Q%2FFXbPC4l72UZG5EPL; unb=1090955643; uc3=lg2=URm48syIIVrSKA%3D%3D&vt3=F8dD3CN8OeVNvwzcYxE%3D&nk2=sCJAj0Qx6%2FoezQ%3D%3D&id2=UoH2iZs9kSfwKw%3D%3D; csg=59712266; lgc=%5Cu82F1%5Cu96C4%5Cu4EA6%5Cu6789%5Cu7136; cancelledSubSites=empty; cookie17=UoH2iZs9kSfwKw%3D%3D; dnk=%5Cu82F1%5Cu96C4%5Cu4EA6%5Cu6789%5Cu7136; skt=ee5511c55d605832; existShop=MTcwMDk4NDg2OA%3D%3D; uc4=nk4=0%40strXCZmJJA%2BRBVfP5847%2BCK62JpI&id4=0%40UOnpLhsAbrpKodYfPTSqudjqLIf3; tracknick=%5Cu82F1%5Cu96C4%5Cu4EA6%5Cu6789%5Cu7136; _cc_=U%2BGCWk%2F7og%3D%3D; _l_g_=Ug%3D%3D; sg=%E7%84%B630; _nk_=%5Cu82F1%5Cu96C4%5Cu4EA6%5Cu6789%5Cu7136; cookie1=Vv6fxNwYboXOnA3gl0xkAY1IBt4Q2MMC3HqyTw83URo%3D; mt=ci=3_1; thw=cn; uc1=cookie21=VT5L2FSpdet1EftGlDZ1Vg%3D%3D&cookie15=U%2BGCWk%2F75gdr5Q%3D%3D&existShop=true&cookie14=UoYelQOi8Xx1KA%3D%3D&pas=0&cookie16=VT5L2FSpNgq6fDudInPRgavC%2BQ%3D%3D; l=fB_eOfpePU6roJjjBOfwPurza77OSIRA_uPzaNbMi9fP_d1e5N6PW1EVQZTwC3GVFsbHR3RxBjFXBeYBqIDmtyYmk6mm0mkmnmOk-Wf..; isg=BA4O1vDH5xvs_1MbQIXPqLl8X-TQj9KJWYtpQzhXepHMm671oB8imbRd08f3hMqh', '.taobao.com')
    # h5.urlCreateFunc('https://h5api.m.taobao.com/h5/mtop.user.getusersimple/1.0/?jsv=2.6.1&appKey=12574478&t=1700983359826&sign=8b00a80f1fded8662d00ae20d9b3d81c&api=mtop.user.getUserSimple&v=1.0&ecode=1&sessionOption=AutoLoginOnly&jsonpIncPrefix=liblogin&type=jsonp&dataType=jsonp&callback=mtopjsonpliblogin4&data=%7B%7D')
    h5.qrLogin()
    # h5.clearCookie()
    api, res = h5.getUserSimple()
    h5.createTypes('UserSimpleRes',api.get('data'))